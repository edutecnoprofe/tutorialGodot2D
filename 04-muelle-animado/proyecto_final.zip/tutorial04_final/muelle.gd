extends Area2D


func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D:
		$AnimatedSprite2D.play("saltar")
		body.apply_central_impulse(Vector2.UP * 1000)
