extends RigidBody2D

@export var fuerza = 400


func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ui_up"):
		apply_central_impulse(Vector2.UP * fuerza)
	if Input.is_action_just_pressed("ui_down"):
		apply_central_impulse(Vector2.DOWN * fuerza)
	if Input.is_action_just_pressed("ui_left"):
		apply_central_impulse(Vector2.LEFT * fuerza)
	if Input.is_action_just_pressed("ui_right"):
		apply_central_impulse(Vector2.RIGHT * fuerza)
