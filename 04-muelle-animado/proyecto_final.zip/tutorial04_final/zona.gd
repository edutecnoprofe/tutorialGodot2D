extends Area2D

var contador = 0


func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D:
		contador = contador + 1
		$Contador.text = str(contador)
