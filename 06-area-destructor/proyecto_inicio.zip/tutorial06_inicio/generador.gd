extends Marker2D

var plantilla = preload("res://pelota.tscn")


func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ui_accept"):
		var pelota = plantilla.instantiate()
		pelota.position = position
		get_parent().add_child(pelota)
