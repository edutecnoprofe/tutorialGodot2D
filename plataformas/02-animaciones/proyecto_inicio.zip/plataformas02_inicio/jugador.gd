extends CharacterBody2D

@export var velocidad := 130.0
@export var fuerza_salto := 350.0


func _physics_process(delta: float) -> void:
	# Gravedad: si está en el aire, cae
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Salto: solo si está en el suelo
	if Input.is_action_just_pressed("saltar") and is_on_floor():
		velocity.y = -fuerza_salto

	# Movimiento: -1 izquierda, 0 quieto, 1 derecha
	var direccion := Input.get_axis("izquierda", "derecha")
	velocity.x = direccion * velocidad

	move_and_slide()
