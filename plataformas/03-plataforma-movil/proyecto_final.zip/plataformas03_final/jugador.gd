extends CharacterBody2D

@export var velocidad := 130.0
@export var fuerza_salto := 350.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	# Gravedad: si está en el aire, cae
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Salto: solo si está en el suelo
	if Input.is_action_just_pressed("saltar") and is_on_floor():
		velocity.y = -fuerza_salto

	# Movimiento: -1 izquierda, 0 quieto, 1 derecha
	var direccion := Input.get_axis("izquierda", "derecha")
	velocity.x = direccion * velocidad

	move_and_slide()
	animar(direccion)


func animar(direccion: float) -> void:
	# Mirar hacia donde se mueve
	if direccion != 0:
		sprite.flip_h = direccion < 0

	# Elegir la animación según lo que hace
	if not is_on_floor():
		if velocity.y < 0:
			sprite.play("jump")
		else:
			sprite.play("fall")
	elif direccion != 0:
		sprite.play("run")
	else:
		sprite.play("idle")
