extends Area2D


func _on_body_entered(body: Node2D) -> void:
	# Solo la recoge el jugador
	if body.is_in_group("jugador"):
		print("¡Fruta recogida!")
		$AnimatedSprite2D.play("recoger")


func _on_animated_sprite_2d_animation_finished() -> void:
	# Al terminar la animación «recoger», la fruta desaparece
	queue_free()
