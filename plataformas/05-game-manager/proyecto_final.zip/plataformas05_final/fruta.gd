extends Area2D

@export var puntos := 1


func _on_body_entered(body: Node2D) -> void:
	# Solo la recoge el jugador
	if body.is_in_group("jugador"):
		# Avisamos al GameManager para que sume los puntos
		var game_manager = get_tree().get_first_node_in_group("game_manager")
		game_manager.sumar_puntos(puntos)
		$AnimatedSprite2D.play("recoger")


func _on_animated_sprite_2d_animation_finished() -> void:
	# Al terminar la animación «recoger», la fruta desaparece
	queue_free()
