extends Node2D

signal puntos_cambiados(puntos: int)
signal vidas_cambiadas(vidas: int)

@export var vidas := 3
var puntos := 0


func sumar_puntos(cantidad: int) -> void:
	puntos += cantidad
	print("Puntos: ", puntos)
	puntos_cambiados.emit(puntos)


func perder_vida() -> void:
	vidas -= 1
	print("Vidas: ", vidas)
	vidas_cambiadas.emit(vidas)
	if vidas <= 0:
		get_tree().reload_current_scene()
