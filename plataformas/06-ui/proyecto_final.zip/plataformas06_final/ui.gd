extends CanvasLayer


func _on_game_manager_puntos_cambiados(puntos: int) -> void:
	$Puntos.text = "PUNTOS: " + str(puntos)


func _on_game_manager_vidas_cambiadas(vidas: int) -> void:
	$Vidas.text = "VIDAS: " + str(vidas)
