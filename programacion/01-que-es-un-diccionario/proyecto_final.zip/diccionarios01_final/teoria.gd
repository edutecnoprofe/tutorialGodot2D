extends Node


func _ready() -> void:
	var edades: Dictionary[String, int] = {"Ana": 16, "Luis": 17}

	edades["Marta"] = 16  # añadir
	edades["Ana"] = 17  # cambiar
	print(edades["Luis"])  # leer

	print(edades.has("Pablo"))  # ¿existe?
	print(edades.get("Pablo", 0))  # leer sin error
	edades.erase("Luis")  # borrar

	print(edades.keys())
	print(edades.values())
	print(edades.size())

	for nombre in edades:
		print(nombre, ": ", edades[nombre])
