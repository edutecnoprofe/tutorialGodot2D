extends Control

var inventario: Dictionary[String, int] = {}

@onready var objeto: LineEdit = $Objeto
@onready var mensaje: Label = $Mensaje
@onready var lista: Label = $Lista
@onready var total: Label = $Total


func _on_mas_pressed() -> void:
	var nombre := objeto.text.strip_edges()
	if nombre == "":
		mensaje.text = "Escribe un objeto"
		return
	if inventario.has(nombre):
		inventario[nombre] += 1
	else:
		inventario[nombre] = 1
	mensaje.text = "Añadido: " + nombre
	mostrar()


func _on_menos_pressed() -> void:
	var nombre := objeto.text.strip_edges()
	if not inventario.has(nombre):
		mensaje.text = "No tienes " + nombre
		return
	inventario[nombre] -= 1
	if inventario[nombre] == 0:
		inventario.erase(nombre)
		mensaje.text = "Se acabó: " + nombre
	else:
		mensaje.text = "Gastado: " + nombre
	mostrar()


func mostrar() -> void:
	var texto := ""
	var suma := 0
	for nombre in inventario:
		texto += nombre + ": " + str(inventario[nombre]) + "\n"
		suma += inventario[nombre]
	lista.text = texto
	total.text = "Total: " + str(suma)
