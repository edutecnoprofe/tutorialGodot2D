extends Control

var datos: Dictionary[String, String] = {}

@onready var clave: LineEdit = $Clave
@onready var valor: LineEdit = $Valor
@onready var resultado: Label = $Resultado
@onready var contenido: Label = $Contenido


func mostrar() -> void:
	contenido.text = str(datos)


func _on_anadir_pressed() -> void:
	datos[clave.text] = valor.text
	resultado.text = "Guardado: " + clave.text
	mostrar()


func _on_buscar_pressed() -> void:
	if datos.has(clave.text):
		resultado.text = clave.text + " → " + datos[clave.text]
	else:
		resultado.text = "No existe la clave " + clave.text


func _on_borrar_pressed() -> void:
	if datos.erase(clave.text):
		resultado.text = "Borrada: " + clave.text
	else:
		resultado.text = "No existe la clave " + clave.text
	mostrar()


func _on_claves_pressed() -> void:
	resultado.text = "Claves: " + str(datos.keys())


func _on_valores_pressed() -> void:
	resultado.text = "Valores: " + str(datos.values())


func _on_tamano_pressed() -> void:
	resultado.text = "Tamaño: " + str(datos.size())


func _on_vaciar_pressed() -> void:
	datos.clear()
	resultado.text = "Diccionario vacío"
	mostrar()
