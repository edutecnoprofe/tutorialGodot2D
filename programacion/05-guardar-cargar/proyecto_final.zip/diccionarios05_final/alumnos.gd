extends Control

var alumnos: Dictionary[String, Dictionary] = {}

@onready var codigo: LineEdit = $Codigo
@onready var nombre: LineEdit = $Nombre
@onready var curso: LineEdit = $Curso
@onready var nota: LineEdit = $Nota
@onready var lista: ItemList = $Lista
@onready var info: Label = $Info


func _ready() -> void:
	alumnos["A01"] = {"nombre": "Ana", "curso": "2A", "nota": 7.5}
	alumnos["A02"] = {"nombre": "Luis", "curso": "2B", "nota": 4.0}
	alumnos["A03"] = {"nombre": "Marta", "curso": "2A", "nota": 9.0}
	cargar_archivo()


func mostrar() -> void:
	lista.clear()
	for c in alumnos:
		var a: Dictionary = alumnos[c]
		lista.add_item(c + " · " + a["nombre"] + " · " + a["curso"] + " · " + str(a["nota"]))


func _on_guardar_pressed() -> void:
	var c := codigo.text.strip_edges()
	if c == "":
		info.text = "Escribe un código"
		return
	alumnos[c] = {
		"nombre": nombre.text,
		"curso": curso.text,
		"nota": nota.text.to_float(),
	}
	info.text = "Guardado: " + c
	mostrar()


func _on_borrar_pressed() -> void:
	if alumnos.erase(codigo.text):
		info.text = "Borrado: " + codigo.text
	else:
		info.text = "No existe " + codigo.text
	mostrar()


func _on_lista_item_selected(index: int) -> void:
	var c: String = alumnos.keys()[index]
	var a: Dictionary = alumnos[c]
	codigo.text = c
	nombre.text = a["nombre"]
	curso.text = a["curso"]
	nota.text = str(a["nota"])


func _on_aprobados_pressed() -> void:
	var texto := "Aprobados:\n"
	for c in alumnos:
		if alumnos[c]["nota"] >= 5:
			texto += alumnos[c]["nombre"] + "\n"
	info.text = texto


func _on_media_pressed() -> void:
	if alumnos.is_empty():
		info.text = "No hay alumnos"
		return
	var suma := 0.0
	for c in alumnos:
		suma += alumnos[c]["nota"]
	info.text = "Media: " + str(snapped(suma / alumnos.size(), 0.01))


func _on_por_curso_pressed() -> void:
	var cuenta: Dictionary[String, int] = {}
	for c in alumnos:
		var cur: String = alumnos[c]["curso"]
		cuenta[cur] = cuenta.get(cur, 0) + 1
	var texto := "Alumnos por curso:\n"
	for cur in cuenta:
		texto += cur + ": " + str(cuenta[cur]) + "\n"
	info.text = texto


const RUTA := "user://alumnos.json"


func guardar_archivo() -> void:
	var archivo := FileAccess.open(RUTA, FileAccess.WRITE)
	archivo.store_string(JSON.stringify(alumnos, "\t"))
	archivo.close()
	info.text = "Guardado en " + RUTA


func cargar_archivo() -> void:
	if not FileAccess.file_exists(RUTA):
		info.text = "Todavía no hay archivo"
		mostrar()
		return
	var texto := FileAccess.get_file_as_string(RUTA)
	var leido = JSON.parse_string(texto)
	if leido is Dictionary:
		alumnos.assign(leido)
		info.text = "Cargados " + str(alumnos.size()) + " alumnos"
	mostrar()


func _on_guardar_archivo_pressed() -> void:
	guardar_archivo()


func _on_cargar_archivo_pressed() -> void:
	cargar_archivo()
